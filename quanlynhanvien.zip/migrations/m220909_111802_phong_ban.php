<?php

use yii\db\Migration;

/**
 * Class m220909_111802_phong_ban
 */
class m220909_111802_phong_ban extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m220909_111802_phong_ban cannot be reverted.\n";

        return false;
    }

   
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {
        $this->createTable('phong_ban', [
            'id' => $this->primaryKey(),
            'ma_phong_ban' => $this->string(255)->notNull(),
            'ten_phong_ban' => $this->string(255)->notNull()
        ]);

       
    }

    public function down()
    {
        echo "m220909_111802_phong_ban cannot be reverted.\n";

        return false;
    }
    
}
