<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\NhanVienSearch $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="nhan-vien-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?php echo $form->field($model, 'ma_nv') ?>

    <?= $form->field($model, 'ho_nv') ?>

    <?= $form->field($model, 'ten_nv') ?>

    <?= $form->field($model, 'gioi_tinh') ?>

    <?= $form->field($model, 'ngay_sinh') ?>

    <?php // echo $form->field($model, 'ma_phong_ban') ?>

    <?php // echo $form->field($model, 'que_quan') ?>

    <?php // echo $form->field($model, 'email') ?>



    <div class="form-group">
        <?= Html::submitButton('Tìm kiếm', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Làm mới', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
