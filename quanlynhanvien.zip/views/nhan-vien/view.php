<?php

use app\models\PhongBan;
use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\NhanVien $model */

$this->title = $model->ID;
$this->params['breadcrumbs'][] = ['label' => 'Nhân Viên', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);

?>
<div class="nhan-vien-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Sửa', ['update', 'ID' => $model->ID], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Xóa', ['delete', 'ID' => $model->ID], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Bạn có chắc chắn muốn xóa không',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'ho_nv',
            'ten_nv',
            'gioi_tinh',
            'ngay_sinh',
            [
              "attribute" => "ma_phong_ban",
                "value"=> function($model){
                    return PhongBan::find()->where(["ma_phong_ban"=>$model->ma_phong_ban])->one()->ten_phong_ban;
                }
            ]
            ,
            'que_quan',
            'email:email',
            'ma_nv',
        ],
    ]) ?>

</div>
