<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\PhongBan;
use yii\jui\DatePicker;
/** @var yii\web\View $this */
/** @var app\models\NhanVien $model */
/** @var yii\widgets\ActiveForm $form */

?>

<div class="nhan-vien-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ho_nv')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ten_nv')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gioi_tinh')->dropDownList([0=>"Nam",1=>"Nữ"]) ?>

    <?= $form->field($model, 'ngay_sinh')->widget(DatePicker::classname(),
        [
            'dateFormat' => 'yyyy/MM/dd',
            'clientOptions' => [
                'changeMonth' => true,
                'yearRange' => '1996:2099',
                'changeYear' => true,
                'class'=>'form-control'
            ],
            'options' => ['class' => 'form-control disable']
        ]) ?>

    <?= $form->field($model, 'ma_phong_ban')->dropDownList(
            ArrayHelper::map(
                    PhongBan::find()->all(),"ma_phong_ban","ten_phong_ban")
    ) ?>

    <?= $form->field($model, 'que_quan')->textInput() ?>

    <?= $form->field($model, 'email')->textInput() ?>

    <?= $form->field($model, 'ma_nv')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Lưu', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
