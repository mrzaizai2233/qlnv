<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\PhongBan $model */

$this->title = 'Sửa Phòng Ban: ' . $model->ID;
$this->params['breadcrumbs'][] = ['label' => 'Phòng Ban', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->ID, 'url' => ['view', 'ID' => $model->ID]];
$this->params['breadcrumbs'][] = 'Sửa';
?>
<div class="phong-ban-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
