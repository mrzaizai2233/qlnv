<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\PhongBan $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="phong-ban-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ma_phong_ban')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ten_phong_ban')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Lưu', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
