<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\PhongBan $model */

$this->title = 'Tào Phòng Ban';
$this->params['breadcrumbs'][] = ['label' => 'Phòng Ban', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="phong-ban-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
