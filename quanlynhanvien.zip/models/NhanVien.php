<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "nhan_vien".
 *
 * @property int $ID
 * @property string $ho_nv
 * @property string $ten_nv
 * @property int $gioi_tinh
 * @property string $ngay_sinh
 * @property int $ma_phong_ban
 * @property int $que_quan
 * @property int $email
 * @property int $ma_nv
 */
class NhanVien extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'nhan_vien';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ho_nv', 'ten_nv', 'gioi_tinh', 'ngay_sinh', 'ma_phong_ban', 'que_quan', 'email', 'ma_nv'], 'required'],
            [['gioi_tinh'], 'integer'],
            [['ngay_sinh'], 'safe'],
            [['ho_nv', 'ten_nv', 'que_quan', 'email', 'ma_nv', 'ma_phong_ban'], 'string', 'max' => 255],
            [['ma_nv'], 'unique'],
            [['ma_phong_ban'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'ho_nv' => 'Họ',
            'ten_nv' => 'Tên',
            'gioi_tinh' => 'Giới Tính',
            'ngay_sinh' => 'Ngày Sinh',
            'ma_phong_ban' => 'Mã Phòng Ban',
            'que_quan' => 'Quê Quán',
            'email' => 'Email',
            'ma_nv' => 'Mã NV',
        ];
    }

    /**
     * {@inheritdoc}
     * @return NhanVienQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new NhanVienQuery(get_called_class());
    }

    public function beforeSave($insert)
    {
        return parent::beforeSave($insert);
    }

    public function getPhongBan(){
        return $this->hasOne(PhongBan::class,["id"=>"ma_phong_ban"]);
    }
}
