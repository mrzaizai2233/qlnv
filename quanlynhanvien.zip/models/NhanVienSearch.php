<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\NhanVien;

/**
 * NhanVienSearch represents the model behind the search form of `app\models\NhanVien`.
 */
class NhanVienSearch extends NhanVien
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ID', 'gioi_tinh', 'ma_phong_ban', 'que_quan', 'email', 'ma_nv'], 'integer'],
            [['ho_nv', 'ten_nv', 'ngay_sinh'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = NhanVien::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'ID' => $this->ID,
            'gioi_tinh' => $this->gioi_tinh,
            'ngay_sinh' => $this->ngay_sinh,
            'ma_phong_ban' => $this->ma_phong_ban,
            'que_quan' => $this->que_quan,
            'email' => $this->email,
            'ma_nv' => $this->ma_nv,
        ]);

        $query->andFilterWhere(['like', 'ho_nv', $this->ho_nv])
            ->andFilterWhere(['like', 'ten_nv', $this->ten_nv]);

        return $dataProvider;
    }
}
