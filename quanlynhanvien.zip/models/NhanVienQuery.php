<?php

namespace app\models;

/**
 * This is the ActiveQuery class for [[NhanVien]].
 *
 * @see NhanVien
 */
class NhanVienQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * {@inheritdoc}
     * @return NhanVien[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * {@inheritdoc}
     * @return NhanVien|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
