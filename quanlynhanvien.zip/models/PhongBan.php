<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "phong_ban".
 *
 * @property int $ID
 * @property string $ma_phong_ban
 * @property string $ten_phong_ban
 */
class PhongBan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'phong_ban';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ma_phong_ban', 'ten_phong_ban'], 'required'],
            [['ma_phong_ban', 'ten_phong_ban'], 'string', 'max' => 255],
            [['ma_phong_ban'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'ma_phong_ban' => 'Mã Phòng Ban',
            'ten_phong_ban' => 'Tên Phòng Ban',
        ];
    }

    /**
     * {@inheritdoc}
     * @return PhongBanQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new PhongBanQuery(get_called_class());
    }
}
